// Runs automatically before `npm start`: installs dependencies on first run
// and creates .env.local (where the Gemini key goes) if it is missing.
import { existsSync, copyFileSync } from 'node:fs';
import { execSync } from 'node:child_process';

const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 20 || (major === 20 && minor < 19)) {
  console.error(`\n✖ DealSync needs Node.js 20.19+ (you have ${process.versions.node}). Install the LTS from https://nodejs.org\n`);
  process.exit(1);
}
if (!existsSync('node_modules/vite')) {
  console.log('\n▶ First run: installing dependencies (one-off, ~30s)…\n');
  execSync('npm install --no-audit --no-fund', { stdio: 'inherit' });
}
if (!existsSync('.env.local') && existsSync('.env.example')) {
  copyFileSync('.env.example', '.env.local');
  console.log('▶ Created .env.local — paste your GEMINI_API_KEY there to enable Gemini (optional).');
}
console.log('\n▶ Starting DealSync on http://localhost:5173 …\n');
